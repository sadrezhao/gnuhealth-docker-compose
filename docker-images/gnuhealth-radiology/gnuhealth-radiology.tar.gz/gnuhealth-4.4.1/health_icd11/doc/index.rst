.. SPDX-FileCopyrightText: 2008-2024 Luis Falcón <falcon@gnuhealth.org>
.. SPDX-FileCopyrightText: 2011-2024 GNU Solidario <health@gnusolidario.org>
..
.. SPDX-License-Identifier: CC-BY-SA-4.0

GNU Health ICD-11 Module
##########################

World Health Organization
International Classification of Diseases 11th revision

This package is based on the WHO ICD-11 MMS linearization

