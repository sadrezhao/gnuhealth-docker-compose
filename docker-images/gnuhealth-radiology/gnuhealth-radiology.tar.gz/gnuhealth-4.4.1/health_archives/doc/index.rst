.. SPDX-FileCopyrightText: 2008-2024 Luis Falcón <falcon@gnuhealth.org>
.. SPDX-FileCopyrightText: 2011-2024 GNU Solidario <health@gnusolidario.org>
..
.. SPDX-License-Identifier: CC-BY-SA-4.0
GNU Health Paper Archive module
-------------------------------

Funtionality to locate the patient medical record on paper on each institution.

It also provides information about the status of the document, scanning and attaching it to the electronic record.
