.. SPDX-FileCopyrightText: 2016-2024 GNU Solidario <health@gnusolidario.org>
.. SPDX-FileCopyrightText: 2016-2024 Luis Falcon <falcon@gnuhealth.org
..
.. SPDX-License-Identifier: CC-BY-SA-4.0

GNU Health Calendar for WebDAV3

===============================

The package is the continuation of the CalDAV functionality
for the discontinued Tryton package.


It has been ported to Python 3 and GNU Health.

