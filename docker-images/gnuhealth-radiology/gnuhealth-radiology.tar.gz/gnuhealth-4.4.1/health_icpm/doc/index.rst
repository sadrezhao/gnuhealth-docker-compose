.. SPDX-FileCopyrightText: 2008-2024 Luis Falcón <falcon@gnuhealth.org>
.. SPDX-FileCopyrightText: 2011-2024 GNU Solidario <health@gnusolidario.org>
..
.. SPDX-License-Identifier: CC-BY-SA-4.0

GNU Health ICPM Module
########################

WHO International Classification of Procedures in Medicine.

The International Classification of Procedures in Medicine was first published by the World Health Organization in 1978,
"to present in a systematic fashion the many procedures used in different branches of medicine, a task which
the World Health Organization is undertaking for the first time."

The ICPM is currently being used in countries around the world, but it will be replaced by the ICHI, the International Classification of Health Intervention [1], currently being revised.

http://www.who.int/classifications/ichi/en/

Credits :
Many thanks to Yvonne Webber-Bryan and the Jamaica Ministry of Health for their contribution to this ICPM module.
