.. SPDX-FileCopyrightText: 2008-2024 Luis Falcón <falcon@gnuhealth.org>
.. SPDX-FileCopyrightText: 2011-2024 GNU Solidario <health@gnusolidario.org>
..
.. SPDX-License-Identifier: CC-BY-SA-4.0

GNU Health Federation Interface
--------------------------------

Package to exchange information with the GNU Health Federation
